<div class="modal fade" id="<?= esc($modalId ?? 'confirmModal') ?>" tabindex="-1" aria-labelledby="<?= esc($modalId ?? 'confirmModal') ?>Label" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content radius-16">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title" id="<?= esc($modalId ?? 'confirmModal') ?>Label"><?= esc($modalTitle ?? 'Konfirmasi Tindakan') ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-20">
                <p class="text-secondary-light mb-0"><?= esc($modalMessage ?? 'Apakah Anda yakin ingin melanjutkan tindakan ini?') ?></p>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-outline-neutral-300 radius-8 px-20 py-10" data-bs-dismiss="modal"><?= esc($cancelLabel ?? 'Batal') ?></button>
                <a href="<?= esc($confirmUrl ?? '#') ?>" class="btn btn-<?= esc($confirmType ?? 'primary') ?>-600 radius-8 px-20 py-10" id="<?= esc($modalId ?? 'confirmModal') ?>Btn"><?= esc($confirmLabel ?? 'Konfirmasi') ?></a>
            </div>
        </div>
    </div>
</div>
