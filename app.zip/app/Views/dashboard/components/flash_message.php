<?php
$sess = null;
if (session_status() === PHP_SESSION_ACTIVE) {
    $sess = session();
} elseif (!headers_sent()) {
    try {
        $sess = session();
    } catch (\Throwable $e) {
        $sess = null;
    }
}

$flashMsg = $sess ? ($sess->getFlashdata('message') ?? $sess->getFlashdata('success')) : ($message ?? null);
$flashErr = $sess ? ($sess->getFlashdata('error') ?? $sess->getFlashdata('danger')) : ($error ?? null);
$flashErrors = $sess ? $sess->getFlashdata('errors') : ($errors ?? null);
?>

<?php if (!empty($flashMsg)): ?>
    <div class="alert alert-success alert-dismissible fade show mb-20 radius-8" role="alert">
        <div class="d-flex align-items-center">
            <iconify-icon icon="solar:check-circle-outline" class="text-xl me-8"></iconify-icon>
            <div><?= esc($flashMsg) ?></div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (!empty($flashErr)): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-20 radius-8" role="alert">
        <div class="d-flex align-items-center">
            <iconify-icon icon="solar:danger-triangle-outline" class="text-xl me-8"></iconify-icon>
            <div><?= esc($flashErr) ?></div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (!empty($flashErrors)): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-20 radius-8" role="alert">
        <div class="d-flex align-items-start">
            <iconify-icon icon="solar:danger-triangle-outline" class="text-xl me-8 mt-4"></iconify-icon>
            <div>
                <ul class="mb-0 ps-16">
                    <?php foreach ((array) $flashErrors as $err): ?>
                        <li><?= esc($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
