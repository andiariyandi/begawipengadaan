<!--Page Header Start-->
<section class="page-header">
    <div class="page-header__bg" style="background-image: url(<?= base_url('assets/main/') ?>images/shapes/page-header-bg-shape.png);">
    </div>
    <div class="page-header__shape-4">
        <img src="<?= base_url('assets/main/') ?>images/shapes/page-header-shape-4.png" alt="">
    </div>
    <div class="page-header__shape-5">
        <img src="<?= base_url('assets/main/') ?>images/shapes/page-header-shape-5.png" alt="">
    </div>
    <div class="page-header__social">
        <a href="#">Facebook</a>
        <span>//</span>
        <a href="#">Instagram</a>
        <span>//</span>
        <a href="#">LinkedIn</a>
        <span>//</span>
        <a href="#">Twitter</a>
    </div>
    <div class="container">
        <div class="page-header__inner">
            <div class="page-header__img">
                <img src="<?= base_url('assets/main/') ?>images/resources/page-header-img-1.png" alt="">
                <div class="page-header__shape-1">
                    <img src="<?= base_url('assets/main/') ?>images/shapes/page-header-shape-1.png" alt="">
                </div>
                <div class="page-header__shape-2">
                    <img src="<?= base_url('assets/main/') ?>images/shapes/page-header-shape-2.png" alt="">
                </div>
                <div class="page-header__shape-3">
                    <img src="<?= base_url('assets/main/') ?>images/shapes/page-header-shape-3.png" alt="">
                </div>
            </div>
            <h2><?php if (isset($page_title) && !empty($page_title)) {
                    echo $page_title;
                } ?></h2>
            <div class="thm-breadcrumb__box">
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li><span>//</span></li>
                    <li><?php if (isset($page_title) && !empty($page_title)) {
                            echo $page_title;
                        } ?></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!--Page Header End-->