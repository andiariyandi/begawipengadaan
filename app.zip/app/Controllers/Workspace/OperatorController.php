<?php

namespace App\Controllers\Workspace;

use App\Controllers\BaseController;
use CodeIgniter\Database\ConnectionInterface;

class OperatorController extends BaseController
{
    private ConnectionInterface $db;

    public function __construct()
    {
        $this->db = db_connect();
    }

    public function index()
    {
        $pendingVerif = $this->db->table('profile_verifications')->where('status', 'pending')->countAllResults();
        $pendingEnroll = $this->db->table('enrollments')->where('status', 'pending')->countAllResults();
        $pendingApprov = $this->db->table('approvals')->where('status', 'pending')->countAllResults();
        $activeEvents  = $this->db->table('events')->whereIn('status', ['published', 'ongoing'])->countAllResults();

        // Recent operational activities across queues
        $recentApprovals = $this->db->table('approvals a')
            ->select('a.id, a.resource_type, a.requested_action, a.status, a.created_at, u.name AS requester_name')
            ->join('users u', 'u.id = a.requested_by', 'left')
            ->orderBy('a.created_at', 'DESC')
            ->limit(10)
            ->get()->getResultArray();

        $rows = [];
        foreach ($recentApprovals as $row) {
            $badge = match ($row['status']) {
                'approved' => '<span class="badge bg-success-subtle text-success">Disetujui</span>',
                'rejected' => '<span class="badge bg-danger-subtle text-danger">Ditolak</span>',
                default    => '<span class="badge bg-warning-subtle text-warning">Menunggu</span>',
            };
            $rows[] = [
                '#' . $row['id'],
                esc($row['resource_type'] ?? '-'),
                esc($row['requested_action'] ?? '-'),
                esc($row['requester_name'] ?? 'Sistem'),
                $badge,
                esc(date('d/m/Y H:i', strtotime($row['created_at']))),
            ];
        }

        $sectionContent = [
            'eyebrow'     => 'Operasional',
            'title'       => 'Dashboard Operator',
            'description' => 'Ringkasan antrean kerja, verifikasi, enrollment, dan persetujuan operasional.',
            'cards'       => [
                ['title' => 'Verifikasi Profil', 'value' => sprintf('%02d', $pendingVerif), 'meta' => 'menunggu persetujuan'],
                ['title' => 'Enrollment Kelas', 'value' => sprintf('%02d', $pendingEnroll), 'meta' => 'pendaftaran baru'],
                ['title' => 'Antrean Approval', 'value' => sprintf('%02d', $pendingApprov), 'meta' => 'perlu tindakan'],
                ['title' => 'Event Aktif', 'value' => sprintf('%02d', $activeEvents), 'meta' => 'sedang berjalan / tayang'],
            ],
            'tableTitle'  => 'Antrean Persetujuan & Operasional Terkini',
            'table'       => [
                'headers' => ['ID', 'Resource', 'Tindakan', 'Pemohon', 'Status', 'Waktu Pengajuan'],
                'rows'    => $rows,
            ],
            'items'       => [
                ['label' => 'Tinjau Antrean Verifikasi Profil Pengguna', 'url' => route_to('workspace.operator.profile-verifications'), 'btn' => 'Buka Verifikasi'],
                ['label' => 'Validasi Pendaftaran Enrollment Kelas', 'url' => route_to('workspace.operator.enrollments'), 'btn' => 'Buka Enrollment'],
                ['label' => 'Monitoring Event & Presensi Kehadiran', 'url' => route_to('workspace.operator.events'), 'btn' => 'Buka Event'],
                ['label' => 'Persetujuan Operasional & Sertifikat', 'url' => route_to('workspace.operator.approvals'), 'btn' => 'Buka Approval'],
            ],
        ];

        return $this->renderOperasional('Dashboard Operator', $sectionContent);
    }

    public function profileVerifications()
    {
        $pending  = $this->db->table('profile_verifications')->where('status', 'pending')->countAllResults();
        $approved = $this->db->table('profile_verifications')->where('status', 'approved')->countAllResults();
        $rejected = $this->db->table('profile_verifications')->where('status', 'rejected')->countAllResults();

        $list = $this->db->table('profile_verifications pv')
            ->select('pv.id, pv.verification_type, pv.status, pv.created_at, u.name, u.email')
            ->join('users u', 'u.id = pv.user_id')
            ->orderBy('pv.created_at', 'DESC')
            ->limit(25)
            ->get()->getResultArray();

        $rows = [];
        foreach ($list as $item) {
            $badge = match ($item['status']) {
                'approved' => '<span class="badge bg-success-subtle text-success">Disetujui</span>',
                'rejected' => '<span class="badge bg-danger-subtle text-danger">Ditolak</span>',
                default    => '<span class="badge bg-warning-subtle text-warning">Menunggu</span>',
            };

            $actionBtn = '-';
            if ($item['status'] === 'pending') {
                $approveUrl = route_to('workspace.operator.profile-verifications.approve', $item['id']);
                $rejectUrl  = route_to('workspace.operator.profile-verifications.reject', $item['id']);
                $csrf       = csrf_field();
                $actionBtn  = '<div class="d-flex gap-1">' .
                    '<form action="' . $approveUrl . '" method="post" class="d-inline">' . $csrf . '<button type="submit" class="btn btn-sm btn-success py-0 px-2">Setujui</button></form>' .
                    '<form action="' . $rejectUrl . '" method="post" class="d-inline">' . $csrf . '<input type="hidden" name="reason" value="Data profil ditolak oleh Operator."><button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm(\'Tolak verifikasi ini?\')">Tolak</button></form>' .
                    '</div>';
            }

            $rows[] = [
                '#' . $item['id'],
                '<strong>' . esc($item['name'] ?? '-') . '</strong><br><small class="text-muted">' . esc($item['email'] ?? '') . '</small>',
                '<span class="badge bg-light text-dark">' . esc($item['verification_type'] ?? 'umum') . '</span>',
                $badge,
                esc(date('d/m/Y H:i', strtotime($item['created_at']))),
                $actionBtn,
            ];
        }

        $sectionContent = [
            'eyebrow'     => 'Operasional Akses',
            'title'       => 'Verifikasi Profil',
            'description' => 'Daftar pengajuan verifikasi identitas dan tipe profil pengguna.',
            'cards'       => [
                ['title' => 'Menunggu Verifikasi', 'value' => sprintf('%02d', $pending), 'meta' => 'pengajuan aktif'],
                ['title' => 'Telah Disetujui', 'value' => sprintf('%02d', $approved), 'meta' => 'terverifikasi'],
                ['title' => 'Ditolak / Revisi', 'value' => sprintf('%02d', $rejected), 'meta' => 'membutuhkan perbaikan'],
            ],
            'tableTitle'  => 'Daftar Pengajuan Verifikasi Profil',
            'table'       => [
                'headers' => ['ID', 'Nama / Email', 'Tipe Verifikasi', 'Status', 'Tanggal Pengajuan', 'Aksi'],
                'rows'    => $rows,
            ],
            'items'       => [
                ['label' => 'Kelola Seluruh Profil Pengguna di Dashboard Akses', 'url' => site_url('dashboard/akses/verifikasi-profil'), 'btn' => 'Buka Admin'],
            ],
        ];

        return $this->renderOperasional('Verifikasi Profil', $sectionContent);
    }

    public function enrollments()
    {
        $pending   = $this->db->table('enrollments')->where('status', 'pending')->countAllResults();
        $active    = $this->db->table('enrollments')->where('status', 'active')->countAllResults();
        $completed = $this->db->table('enrollments')->where('status', 'completed')->countAllResults();

        $list = $this->db->table('enrollments e')
            ->select('e.id, e.status, e.enrolled_at, e.final_score, u.name, u.email, lc.name AS class_name')
            ->join('users u', 'u.id = e.user_id')
            ->join('learning_classes lc', 'lc.id = e.class_id')
            ->orderBy('e.created_at', 'DESC')
            ->limit(25)
            ->get()->getResultArray();

        $rows = [];
        foreach ($list as $item) {
            $badge = match ($item['status']) {
                'active'    => '<span class="badge bg-primary-subtle text-primary">Aktif</span>',
                'completed' => '<span class="badge bg-success-subtle text-success">Selesai</span>',
                'cancelled' => '<span class="badge bg-danger-subtle text-danger">Dibatalkan</span>',
                default     => '<span class="badge bg-warning-subtle text-warning">Menunggu</span>',
            };

            $actionBtn = '-';
            if ($item['status'] === 'pending') {
                $actUrl    = route_to('workspace.operator.enrollments.activate', $item['id']);
                $csrf      = csrf_field();
                $actionBtn = '<form action="' . $actUrl . '" method="post" class="d-inline">' . $csrf . '<button type="submit" class="btn btn-sm btn-primary py-0 px-2">Aktifkan</button></form>';
            }

            $rows[] = [
                '#' . $item['id'],
                '<strong>' . esc($item['name'] ?? '-') . '</strong><br><small class="text-muted">' . esc($item['email'] ?? '') . '</small>',
                esc($item['class_name'] ?? '-'),
                $badge,
                $item['final_score'] !== null ? number_format((float) $item['final_score'], 1) : '-',
                esc(date('d/m/Y H:i', strtotime($item['enrolled_at'] ?? 'now'))),
                $actionBtn,
            ];
        }

        $sectionContent = [
            'eyebrow'     => 'Operasional Pembelajaran',
            'title'       => 'Enrollment Kelas',
            'description' => 'Monitoring kepesertaan kelas dan progres enrollment peserta.',
            'cards'       => [
                ['title' => 'Pending Enrollment', 'value' => sprintf('%02d', $pending), 'meta' => 'pendaftaran menunggu aktivasi'],
                ['title' => 'Enrollment Aktif', 'value' => sprintf('%02d', $active), 'meta' => 'peserta aktif belajar'],
                ['title' => 'Lulus / Selesai', 'value' => sprintf('%02d', $completed), 'meta' => 'telah menyelesaikan kurikulum'],
            ],
            'tableTitle'  => 'Daftar Kepesertaan Kelas Terkini',
            'table'       => [
                'headers' => ['ID', 'Peserta', 'Kelas', 'Status', 'Nilai Akhir', 'Waktu Daftar', 'Aksi'],
                'rows'    => $rows,
            ],
            'items'       => [
                ['label' => 'Lihat Katalog Kelas Pembelajaran', 'url' => site_url('katalog'), 'btn' => 'Buka Katalog'],
            ],
        ];

        return $this->renderOperasional('Enrollment Kelas', $sectionContent);
    }

    public function events()
    {
        $published = $this->db->table('events')->where('status', 'published')->countAllResults();
        $draft     = $this->db->table('events')->where('status', 'draft')->countAllResults();
        $ongoing   = $this->db->table('events')->where('status', 'ongoing')->countAllResults();

        $list = $this->db->table('events')
            ->select('id, title, type, mode, status, start_at, capacity')
            ->orderBy('created_at', 'DESC')
            ->limit(25)
            ->get()->getResultArray();

        $rows = [];
        foreach ($list as $item) {
            $badge = match ($item['status']) {
                'published' => '<span class="badge bg-success-subtle text-success">Tayang</span>',
                'ongoing'   => '<span class="badge bg-primary-subtle text-primary">Berlangsung</span>',
                'completed' => '<span class="badge bg-secondary-subtle text-secondary">Selesai</span>',
                default     => '<span class="badge bg-warning-subtle text-warning">Draft</span>',
            };
            $rows[] = [
                '#' . $item['id'],
                '<strong>' . esc($item['title'] ?? '-') . '</strong>',
                '<span class="badge bg-light text-dark">' . esc($item['type'] ?? '-') . ' / ' . esc($item['mode'] ?? '-') . '</span>',
                $badge,
                (int) ($item['capacity'] ?? 0) . ' Kursi',
                $item['start_at'] ? esc(date('d/m/Y H:i', strtotime($item['start_at']))) : '-',
            ];
        }

        $sectionContent = [
            'eyebrow'     => 'Operasional Event',
            'title'       => 'Manajemen Event',
            'description' => 'Operasional seminar, workshop, bimbingan teknis, dan event PBJ.',
            'cards'       => [
                ['title' => 'Event Tayang', 'value' => sprintf('%02d', $published), 'meta' => 'pendaftaran terbuka'],
                ['title' => 'Event Berlangsung', 'value' => sprintf('%02d', $ongoing), 'meta' => 'sedang diselenggarakan'],
                ['title' => 'Draft Event', 'value' => sprintf('%02d', $draft), 'meta' => 'dalam persiapan'],
            ],
            'tableTitle'  => 'Daftar Event & Workshop PBJ',
            'table'       => [
                'headers' => ['ID', 'Judul Event', 'Tipe / Moda', 'Status', 'Kapasitas', 'Jadwal Mulai'],
                'rows'    => $rows,
            ],
            'items'       => [
                ['label' => 'Lihat Agenda Event Publik', 'url' => site_url('event'), 'btn' => 'Buka Event Publik'],
            ],
        ];

        return $this->renderOperasional('Manajemen Event', $sectionContent);
    }

    public function attendance()
    {
        $recorded = $this->db->table('attendances')->countAllResults();
        $registrations = $this->db->table('event_registrations')->countAllResults();

        $list = $this->db->table('attendances a')
            ->select('a.id, a.status, a.recorded_at, ev.title AS event_title, u.name AS user_name, u.email AS user_email')
            ->join('event_registrations er', 'er.id = a.event_registration_id')
            ->join('events ev', 'ev.id = er.event_id')
            ->join('users u', 'u.id = er.user_id')
            ->orderBy('a.created_at', 'DESC')
            ->limit(25)
            ->get()->getResultArray();

        $rows = [];
        foreach ($list as $item) {
            $badge = match ($item['status']) {
                'present' => '<span class="badge bg-success-subtle text-success">Hadir</span>',
                'absent'  => '<span class="badge bg-danger-subtle text-danger">Tidak Hadir</span>',
                default   => '<span class="badge bg-secondary-subtle text-secondary">' . esc($item['status']) . '</span>',
            };
            $rows[] = [
                '#' . $item['id'],
                esc($item['event_title'] ?? '-'),
                '<strong>' . esc($item['user_name'] ?? '-') . '</strong><br><small class="text-muted">' . esc($item['user_email'] ?? '') . '</small>',
                $badge,
                $item['recorded_at'] ? esc(date('d/m/Y H:i', strtotime($item['recorded_at']))) : '-',
            ];
        }

        $sectionContent = [
            'eyebrow'     => 'Presensi & Kehadiran',
            'title'       => 'Pencatatan Kehadiran',
            'description' => 'Monitoring presensi peserta dalam kegiatan pembelajaran dan event PBJ.',
            'cards'       => [
                ['title' => 'Total Presensi Tercatat', 'value' => sprintf('%02d', $recorded), 'meta' => 'catatan kehadiran'],
                ['title' => 'Pendaftaran Event', 'value' => sprintf('%02d', $registrations), 'meta' => 'total peserta terdaftar'],
            ],
            'tableTitle'  => 'Catatan Presensi Terkini',
            'table'       => [
                'headers' => ['ID', 'Nama Event', 'Peserta', 'Status', 'Waktu Tercatat'],
                'rows'    => $rows,
            ],
            'items'       => [
                ['label' => 'Kelola Event & Pendaftaran Peserta', 'url' => route_to('workspace.operator.events'), 'btn' => 'Buka Event'],
            ],
        ];

        return $this->renderOperasional('Kehadiran', $sectionContent);
    }

    public function approvals()
    {
        $pending  = $this->db->table('approvals')->where('status', 'pending')->countAllResults();
        $approved = $this->db->table('approvals')->where('status', 'approved')->countAllResults();
        $rejected = $this->db->table('approvals')->where('status', 'rejected')->countAllResults();

        $list = $this->db->table('approvals a')
            ->select('a.id, a.resource_type, a.requested_action, a.status, a.reason, a.created_at, u.name AS requester_name')
            ->join('users u', 'u.id = a.requested_by', 'left')
            ->orderBy('a.created_at', 'DESC')
            ->limit(25)
            ->get()->getResultArray();

        $rows = [];
        foreach ($list as $item) {
            $badge = match ($item['status']) {
                'approved' => '<span class="badge bg-success-subtle text-success">Disetujui</span>',
                'rejected' => '<span class="badge bg-danger-subtle text-danger">Ditolak</span>',
                default    => '<span class="badge bg-warning-subtle text-warning">Menunggu</span>',
            };

            $actionBtn = '-';
            if ($item['status'] === 'pending') {
                $approveUrl = route_to('workspace.operator.approvals.approve', $item['id']);
                $rejectUrl  = route_to('workspace.operator.approvals.reject', $item['id']);
                $csrf       = csrf_field();
                $actionBtn  = '<div class="d-flex gap-1">' .
                    '<form action="' . $approveUrl . '" method="post" class="d-inline">' . $csrf . '<button type="submit" class="btn btn-sm btn-success py-0 px-2">Setujui</button></form>' .
                    '<form action="' . $rejectUrl . '" method="post" class="d-inline">' . $csrf . '<input type="hidden" name="reason" value="Approval ditolak oleh Operator."><button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm(\'Tolak approval ini?\')">Tolak</button></form>' .
                    '</div>';
            }

            $rows[] = [
                '#' . $item['id'],
                '<span class="badge bg-light text-dark">' . esc($item['resource_type'] ?? '-') . '</span>',
                '<strong>' . esc($item['requested_action'] ?? '-') . '</strong>',
                esc($item['requester_name'] ?? 'Sistem'),
                $badge,
                esc(date('d/m/Y H:i', strtotime($item['created_at']))),
                $actionBtn,
            ];
        }

        $sectionContent = [
            'eyebrow'     => 'Antrean Persetujuan',
            'title'       => 'Antrean Approval',
            'description' => 'Persetujuan operasional sertifikat, verifikasi profil, dan perubahan hak akses.',
            'cards'       => [
                ['title' => 'Menunggu Approval', 'value' => sprintf('%02d', $pending), 'meta' => 'perlu tindakan'],
                ['title' => 'Telah Disetujui', 'value' => sprintf('%02d', $approved), 'meta' => 'disetujui'],
                ['title' => 'Ditolak', 'value' => sprintf('%02d', $rejected), 'meta' => 'ditolak'],
            ],
            'tableTitle'  => 'Daftar Pengajuan Approval Sistem',
            'table'       => [
                'headers' => ['ID', 'Tipe Objek', 'Tindakan', 'Diajukan Oleh', 'Status', 'Waktu Pengajuan', 'Aksi'],
                'rows'    => $rows,
            ],
            'items'       => [
                ['label' => 'Buka Modul Sertifikat Pembelajaran', 'url' => site_url('dashboard/sertifikat'), 'btn' => 'Buka Sertifikat'],
            ],
        ];

        return $this->renderOperasional('Antrean Approval', $sectionContent);
    }

    public function approveVerification(string $id)
    {
        $verificationId = (int) $id;
        $actorId = (int) (session()->get('user_id') ?: 1);
        $notes = (string) $this->request->getPost('notes');

        $service = new \App\Services\Admin\ProfileVerificationService();
        if ($service->approve($verificationId, $actorId, $notes)) {
            return redirect()->back()->with('message', 'Pengajuan verifikasi profil #' . $verificationId . ' berhasil disetujui.');
        }
        return redirect()->back()->with('error', 'Verifikasi profil tidak ditemukan.');
    }

    public function rejectVerification(string $id)
    {
        $verificationId = (int) $id;
        $actorId = (int) (session()->get('user_id') ?: 1);
        $reason = trim((string) $this->request->getPost('reason')) ?: 'Data profil tidak sesuai.';
        $notes = (string) $this->request->getPost('notes');

        $service = new \App\Services\Admin\ProfileVerificationService();
        try {
            if ($service->reject($verificationId, $reason, $actorId, $notes)) {
                return redirect()->back()->with('message', 'Pengajuan verifikasi profil #' . $verificationId . ' telah ditolak.');
            }
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
        return redirect()->back()->with('error', 'Verifikasi profil tidak ditemukan.');
    }

    public function activateEnrollment(string $id)
    {
        $enrollmentId = (int) $id;
        $learning = new \App\Services\LearningService($this->db);
        try {
            $learning->activateEnrollment($enrollmentId);
            return redirect()->back()->with('message', 'Enrollment #' . $enrollmentId . ' berhasil diaktifkan.');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function approveApproval(string $id)
    {
        $approvalId = (int) $id;
        $actorId = (int) (session()->get('user_id') ?: 1);
        $notes = (string) $this->request->getPost('notes') ?: 'Disetujui oleh Operator.';

        $approval = $this->db->table('approvals')->where('id', $approvalId)->get()->getRowArray();
        if (! $approval) {
            return redirect()->back()->with('error', 'Approval tidak ditemukan.');
        }

        $now = date('Y-m-d H:i:s');
        $this->db->table('approvals')->where('id', $approvalId)->update([
            'status'      => 'approved',
            'reviewed_by' => $actorId,
            'reviewed_at' => $now,
            'notes'       => $notes,
            'updated_at'  => $now,
        ]);

        if (($approval['resource_type'] ?? '') === 'certificate' && ($approval['requested_action'] ?? '') === 'issue_certificate') {
            try {
                $generator = new \App\Services\CertificateGenerator();
                $result = $generator->generateFromApproval($approvalId, $actorId);
                return redirect()->back()->with('message', 'Approval disetujui dan Sertifikat #' . ($result['certificate_number'] ?? '') . ' berhasil diterbitkan.');
            } catch (\Throwable $e) {
                return redirect()->back()->with('error', 'Approval disetujui, namun pembuatan file sertifikat mengalami kendala: ' . $e->getMessage());
            }
        }

        return redirect()->back()->with('message', 'Approval #' . $approvalId . ' berhasil disetujui.');
    }

    public function rejectApproval(string $id)
    {
        $approvalId = (int) $id;
        $actorId = (int) (session()->get('user_id') ?: 1);
        $reason = trim((string) $this->request->getPost('reason')) ?: 'Pengajuan ditolak oleh Operator.';

        $approval = $this->db->table('approvals')->where('id', $approvalId)->get()->getRowArray();
        if (! $approval) {
            return redirect()->back()->with('error', 'Approval tidak ditemukan.');
        }

        $now = date('Y-m-d H:i:s');
        $this->db->table('approvals')->where('id', $approvalId)->update([
            'status'      => 'rejected',
            'reviewed_by' => $actorId,
            'reviewed_at' => $now,
            'reason'      => $reason,
            'updated_at'  => $now,
        ]);

        return redirect()->back()->with('message', 'Approval #' . $approvalId . ' telah ditolak.');
    }

    private function renderOperasional(string $title, array $sectionContent): string
    {
        $userName = (string) (session()->get('name') ?: session()->get('username') ?: 'Operator');

        return view('main/workspace/pages/operasional', [
            'title'          => $title . ' | Operator BegawiPBJ',
            'pageTitle'      => $title,
            'userName'       => $userName,
            'roles'          => ['operator'],
            'primaryRole'    => 'operator',
            'roleLabel'      => 'Operator',
            'menuItems'      => $this->menuItems(),
            'sectionContent' => $sectionContent,
        ]);
    }

    private function menuItems(): array
    {
        $workspace = route_to('workspace.home');
        $section = static fn (string $name): string => route_to('workspace.section', $name);

        return [
            ['label' => 'Dashboard', 'items' => [
                ['label' => 'Ringkasan', 'url' => $workspace],
                ['label' => 'Aktivitas Terakhir', 'url' => $section('aktivitas')],
            ]],
            ['label' => 'Operasional', 'items' => [
                ['label' => 'Verifikasi Profil', 'url' => route_to('workspace.operator.profile-verifications')],
                ['label' => 'Enrollment', 'url' => route_to('workspace.operator.enrollments')],
                ['label' => 'Event', 'url' => route_to('workspace.operator.events')],
                ['label' => 'Kehadiran', 'url' => route_to('workspace.operator.attendance')],
                ['label' => 'Approval', 'url' => route_to('workspace.operator.approvals')],
            ]],
        ];
    }
}
